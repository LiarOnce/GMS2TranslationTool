#include <stdio.h>
#include <unistd.h>
#include <iostream>
#include <fstream>
#include <string>

#include <sys/types.h>
#include <sys/stat.h>

#if defined(_WIN32)
    #include <direct.h>
    #include <windows.h>
    #include <shellapi.h>
    #include <tchar.h>
#else
    #include <fts.h>
    #include <libgen.h>
    #if defined(__APPLE__)
        #include <mach-o/dyld.h>
        #include <limits.h>
    #else
        #include <linux/limits.h>
    #endif
#endif

extern "C"
{
    double file_copy(char *source,char *destination)
    {
        std::ifstream srce(source,std::ios::binary);
        if (srce.tellg() < 0) return 0;

        std::ofstream dest(destination,std::ios::binary);
        if (dest.tellp() < 0) return 0;

        dest << srce.rdbuf();
        if (srce.tellg()-dest.tellp() != 0) return 0;

        return 1;
    }

    double file_move(char *source,char *destination)
    {
        return (rename(source,destination) == 0);
    }

    double file_rename(char *oldname,char *newname)
    {
        return (rename(oldname,newname) == 0);
    }

    double file_exists(char *filename)
    {
        std::ifstream infile(filename);
        return (bool)infile.good();
    }

    double file_delete(char *filename)
    {
        return (remove(filename) == 0);
    }

    double directory_create(char *pathname)
    {
        std::string str(pathname);
        if (!str.empty())
        {
            while (*str.rbegin() == '\\' || *str.rbegin() == '/')
            {
                str.erase(str.size()-1);
            }
        }

        #if defined(_WIN32)
            return (_mkdir((char *)str.c_str()) == 0);
        #else
            return (mkdir((char *)str.c_str(),0777) == 0);
        #endif
    }

    double directory_exists(char *pathname)
    {
        std::string str(pathname);
        if (!str.empty())
        {
            while (*str.rbegin() == '\\' || *str.rbegin() == '/')
            {
                str.erase(str.size()-1);
            }
        }

        struct stat sb;
        return (stat((char *)str.c_str(),&sb) == 0 &&
                S_ISDIR(sb.st_mode));
    }

    double directory_delete(char *pathname)
    {
        std::string str(pathname);
        if (!str.empty())
        {
            while (*str.rbegin() == '\\' || *str.rbegin() == '/')
            {
                str.erase(str.size()-1);
            }
        }

        #if defined(_WIN32)
            int len = _tcslen((char *)str.c_str());
            TCHAR *pszFrom = new TCHAR[len+2];
            _tcscpy(pszFrom,(char *)str.c_str());
            pszFrom[len] = 0;
            pszFrom[len+1] = 0;

            SHFILEOPSTRUCT fileop;
            fileop.hwnd = NULL;
            fileop.wFunc = FO_DELETE;
            fileop.pFrom = pszFrom;
            fileop.pTo = NULL;
            fileop.fFlags = FOF_NOCONFIRMATION|FOF_SILENT;
            fileop.fAnyOperationsAborted = FALSE;
            fileop.lpszProgressTitle = NULL;
            fileop.hNameMappings = NULL;

            return (SHFileOperation(&fileop) == 0);
            delete [] pszFrom;
        #else
            int ret = 0;
            FTS *ftsp = NULL;
            FTSENT *curr;

            char *files[] = {(char *)str.c_str(),NULL};
            ftsp = fts_open(files,FTS_NOCHDIR|FTS_PHYSICAL|FTS_XDEV,NULL);
            if (!ftsp)
            {
                ret = -1;
                goto finish;
            }

            while ((curr = fts_read(ftsp)))
            {
                switch (curr->fts_info)
                {
                    case FTS_NS:
                    case FTS_DNR:
                    case FTS_ERR:
                        ret = -1;
                        break;

                    case FTS_DC:
                    case FTS_DOT:
                    case FTS_NSOK:
                        break;

                    case FTS_D:
                        break;

                    case FTS_DP:
                    case FTS_F:
                    case FTS_SL:
                    case FTS_SLNONE:
                    case FTS_DEFAULT:
                        if (remove(curr->fts_accpath) < 0)
                        {
                            ret = -1;
                        }
                        break;
                }
            }

            finish:
                if (ftsp)
                {
                    fts_close(ftsp);
                }

            return (ret == 0);
        #endif
    }

    char *program_directory()
    {
        #if defined(_WIN32)
            char result[MAX_PATH];
            GetModuleFileName(NULL,result,MAX_PATH);
            std::string::size_type pos = std::string(result).find_last_of("\\/");
            if (pos != std::string::npos)
            {
                return (char *)std::string(std::string(result).substr(0,pos)+std::string("\\")).c_str();
            }
            else
            {
                return (char *)"";
            }
        #endif
        #if defined(__APPLE__)
            char result[PATH_MAX];
            uint32_t size = sizeof(result);
            if (_NSGetExecutablePath(result,&size) == 0)
            {
                std::string str(dirname(result));
                return (char *)std::string(str+std::string("/")).c_str();
            }
            else
            {
                return (char *)"";
            }
        #endif
        #if defined(linux)
            char result[PATH_MAX];
            ssize_t count = readlink("/proc/self/exe",result,PATH_MAX);
            if (count != -1)
            {
                std::string str(dirname(result));
                return (char *)std::string(str+std::string("/")).c_str();
            }
            else
            {
                return (char *)"";
            }
        #endif
        return (char *)"";
    }
}
